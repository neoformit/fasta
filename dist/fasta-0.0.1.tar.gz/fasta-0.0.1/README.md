# fasta
A simple parser and writer for FASTA files
